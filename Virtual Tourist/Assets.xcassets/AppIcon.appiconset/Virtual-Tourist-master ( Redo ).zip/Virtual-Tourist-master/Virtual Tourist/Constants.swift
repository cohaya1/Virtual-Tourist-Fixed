//
//  Constants.swift
//  Virtual Tourist
//
//  Created by Makaveli Ohaya on 4/22/20.
//  Copyright © 2020 Ohaya. All rights reserved.
//

import Foundation
